# Salesforce VPA Email Sender — Chrome Extension

A Chrome extension that adds a **"📧 Send VPA Email"** button to Salesforce Lead/Contact pages. When clicked, it scrapes lead data from Salesforce, creates a Gmail draft with a pre-filled HTML email template, and auto-attaches PDF files from Google Drive.

---

## 👤 New User?

**👉 [Read the Setup Guide (SETUP.md)](SETUP.md)** — step-by-step instructions with screenshots for installing and configuring the extension on your computer.

---

## Features

- 🟦 Native-looking button on Salesforce Lightning Lead/Contact pages
- 🔍 Scrapes lead data (name, email, purchase price/loan amount, agent, co-borrower) from the page
- 📧 Creates a Gmail draft via the Gmail API with a formatted HTML email
- 📎 Auto-attaches PDFs from Google Drive (appraisal certificate, profile one-pager) plus a user-selected pre-approval letter
- 🤝 Co-borrower email goes to **To:**, agent email goes to **CC:** (auto-detected via SF hover cards)
- ⚪ Button shown grey/disabled unless lead is in **Pre-Approval** status
- ⚙️ Configurable Salesforce field labels and Loan Officer info
- 🔁 Survives Salesforce SPA navigation (workspace tab switching)

---

## Quick Start

For end users — see **[SETUP.md](SETUP.md)** for detailed instructions with screenshots.

For developers / admins setting up the OAuth project — see [Admin Setup](#admin-setup-google-cloud-oauth) below.

---

## Admin Setup (Google Cloud OAuth)

> Already done by the project owner. Only needed if creating a new instance from scratch.

### 1. Google Cloud Console

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project (e.g. "VPA Email Extension")
3. Enable the following APIs:
   - **Gmail API**
   - **Google Drive API**
4. Configure the **OAuth consent screen**:
   - User Type: **External**
   - Add test users (each loan officer's email)
   - Add scopes:
     - `https://www.googleapis.com/auth/gmail.compose`
     - `https://www.googleapis.com/auth/gmail.send`
     - `https://www.googleapis.com/auth/drive.readonly`
5. Go to **Credentials → Create Credentials → OAuth Client ID**
   - Application type: **Chrome Extension**
   - Item ID: `dgpmdgbnpmnegpijjgneafepgnifecgo` (the fixed extension ID — see manifest `key`)
6. Update `manifest.json` with the new OAuth Client ID

### 2. Adding New Test Users

When a new loan officer wants to use the extension:

1. Go to Google Cloud Console → **Google Auth Platform → Audience**
2. Under **Test users**, click **Add users**
3. Enter their work Google email
4. Save

The user's email is now authorized to use the extension.

---

## Extension Structure

```
├── manifest.json              Manifest V3 + fixed extension key
├── SETUP.md                   New-user setup guide (with screenshots)
├── README.md                  This file
├── content-scripts/
│   └── salesforce.js          Button injection & SF data scraping
├── background/
│   └── service-worker.js      Gmail/Drive API, OAuth, MIME construction
├── popup/
│   ├── popup.html             Extension popup UI
│   └── popup.js
├── options/
│   ├── options.html           Guided setup & settings page
│   └── options.js
├── templates/
│   └── vpa-template.html      Email HTML template (reference copy)
├── icons/                     Extension icons (16/48/128)
├── docs/images/               Setup guide screenshots
└── styles/
    └── salesforce-button.css  Injected button styles
```

---

## Troubleshooting

- **Button doesn't appear**: Refresh the Salesforce page. If the lead is not in Pre-Approval status, the button will be greyed out.
- **"Access blocked" error**: Your work email needs to be added as a test user in Google Cloud Console.
- **Attachment errors**: Verify the Drive file IDs in Settings and that your account has read access.
- **Fields show placeholders**: The extension couldn't find the field. Check field label configuration in Settings.
- **Wrong lead's data**: Make sure you're on the visible Salesforce tab — the extension scrapes the currently visible lead.

# 🚀 VPA Email Extension — Setup Guide

Welcome! This guide will walk you through setting up the **Send VPA Email** Chrome extension. Setup takes about 5 minutes.

---

## Step 1: Download the Extension

1. You should have received a **ZIP file** named `SFGmail.zip` (or similar) from Justin
2. Save it somewhere easy to find, like your **Desktop** or **Downloads** folder

![Step 1 - Downloaded ZIP file on desktop](docs/images/01-zip-downloaded.png)

---

## Step 2: Unzip the File

### Windows
1. **Right-click** the ZIP file
2. Select **Extract All...**
3. Choose a location (your **Desktop** is a good choice — make sure you can find this folder later!)
4. Click **Extract**
5. **Rename** the extracted folder to **`SF-Gmail-VPA`** (optional but makes it easier to find)

![Step 2 - Right-click extract all](docs/images/02-extract-zip.png)

### Mac
1. **Double-click** the ZIP file — it will automatically extract to a folder
2. **Rename** the folder to **`SF-Gmail-VPA`** (optional but makes it easier to find)

> ⚠️ **Important:** Don't delete this folder! Chrome will need it to remain in place to keep the extension running.

---

## Step 3: Open Chrome Extensions Page

1. Open **Google Chrome**
2. Click the address bar and type: `chrome://extensions/`
3. Press **Enter**

![Step 3 - Chrome extensions URL](docs/images/03-chrome-extensions-url.png)

---

## Step 4: Enable Developer Mode

In the top-right corner of the Extensions page, toggle **Developer mode** to **ON**.

![Step 4 - Developer mode toggle](docs/images/04-developer-mode.png)

> A new row of buttons will appear at the top of the page after enabling this.

---

## Step 5: Load the Extension

1. Click the **Load unpacked** button (top-left)
2. Navigate to where you extracted the ZIP file
3. **Select the folder** (the one containing `manifest.json`) and click **Select Folder**

![Step 5 - Load unpacked button](docs/images/05-load-unpacked.png)

You should now see the **Salesforce VPA Email Sender** extension on the page.

![Step 5b - Extension loaded](docs/images/05b-extension-loaded.png)

---

## Step 6: Pin the Extension (Optional but Recommended)

1. Click the **puzzle piece icon** 🧩 in the top-right of Chrome
2. Find **Salesforce VPA Email Sender**
3. Click the **pin icon** 📌 next to it

![Step 6 - Pin the extension](docs/images/06-pin-extension.png)

The extension icon will now always be visible in your Chrome toolbar.

---

## Step 7: Open Extension Settings

The settings page should have **automatically opened** in a new tab when the extension was first loaded. If not:

1. Click the **extension icon** in your Chrome toolbar
2. Click **Open Settings**

![Step 7 - Open settings from popup](docs/images/07-open-settings.png)

---

## Step 8: Complete Setup in the Extension

The settings page will guide you through the rest of the setup — **everything else is configured inside the extension**. You'll need to:

1. ✅ Connect your Google Account (one click)
2. ✅ Enter your **Loan Officer name and email**
3. ✅ Click **Save Settings**
4. ✅ (Optional) Click **Send Test Email** to verify everything works

![Step 8 - Settings page](docs/images/08-settings-page.png)

---

## ✅ You're Done!

Once you've saved your settings, the extension is ready to use:

1. Open any **Lead** or **Contact** in Salesforce
2. Look for the blue **"📧 Send VPA Email"** button at the top
3. The button will be **grey/disabled** unless the lead is in **Pre-Approval** status

![Done - Button on Salesforce page](docs/images/09-button-on-salesforce.png)

---

## 🆘 Troubleshooting

### "Access blocked" error when connecting Google Account
You need to be added as a **test user** by Justin. Reach out to him with your work Google email and he'll add you.

### Button doesn't appear on Salesforce pages
- Refresh the Salesforce page
- Make sure the extension is **enabled** at `chrome://extensions/`
- Try removing and re-loading the extension

### Test email failed
- Make sure you've saved your settings
- Click **"Reconnect"** on the Google Account section and try again

### Need help?
Reach out to Justin with a screenshot of any errors.

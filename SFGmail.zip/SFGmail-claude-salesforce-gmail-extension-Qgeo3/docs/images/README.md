# Setup Guide Screenshots

Add screenshots here for the [SETUP.md](../../SETUP.md) guide.

## Required Screenshots

| Filename | What to capture |
|----------|----------------|
| `01-zip-downloaded.png` | The downloaded ZIP file on the Desktop or in Downloads |
| `02-extract-zip.png` | Right-click menu showing "Extract All..." option (Windows) |
| `03-chrome-extensions-url.png` | Chrome address bar showing `chrome://extensions/` |
| `04-developer-mode.png` | The Extensions page with Developer mode toggle in top-right (highlighted) |
| `05-load-unpacked.png` | The "Load unpacked" button at the top-left of the Extensions page |
| `05b-extension-loaded.png` | The Extensions page showing the "Salesforce VPA Email Sender" card |
| `06-pin-extension.png` | The puzzle piece menu showing the pin icon next to the extension |
| `07-open-settings.png` | The extension popup with "Open Settings" button |
| `08-settings-page.png` | The full Settings page with all sections visible |
| `09-button-on-salesforce.png` | A Salesforce Lead page with the blue "Send VPA Email" button visible |

## Image Guidelines

- **Format**: PNG preferred
- **Size**: Reasonable size — try to keep each under 500 KB
- **Annotations**: Highlight the relevant area with a red box or arrow if helpful
- **Privacy**: Blur out any personal/customer data before sharing

/**
 * Popup script.
 * Shows auth status, Salesforce page detection, and quick actions.
 */

'use strict';

// ─── Auth Status ─────────────────────────────────────────────────────────────

function checkAuthStatus() {
  const badge = document.getElementById('authBadge');

  chrome.runtime.sendMessage({ type: 'GET_AUTH_STATUS' }, (response) => {
    if (response && response.authenticated) {
      badge.textContent = 'Connected';
      badge.className = 'status-badge status-badge--connected';
    } else {
      badge.textContent = 'Not connected';
      badge.className = 'status-badge status-badge--disconnected';
    }
  });
}

// ─── Salesforce Page Detection ───────────────────────────────────────────────

function checkSalesforcePage() {
  const sfStatus = document.getElementById('sfStatus');
  const sendBtn = document.getElementById('sendBtn');

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) {
      sfStatus.textContent = 'No active tab';
      sendBtn.disabled = true;
      return;
    }

    const tab = tabs[0];
    const url = tab.url || '';

    // Check if the URL matches Salesforce Lead/Contact pattern
    const isSalesforce =
      url.includes('.salesforce.com') || url.includes('.force.com');
    const isRecord = /\/lightning\/r\/(Lead|Contact)\//.test(url);

    if (isSalesforce && isRecord) {
      sfStatus.textContent = 'On Salesforce Lead/Contact page';
      sfStatus.className = 'sf-status sf-status--active';
      sendBtn.disabled = false;

      // Also try to communicate with the content script
      chrome.tabs.sendMessage(
        tab.id,
        { type: 'CHECK_SF_PAGE' },
        (response) => {
          if (chrome.runtime.lastError) {
            // Content script may not be loaded yet
            sfStatus.textContent =
              'Salesforce page detected (refresh may be needed)';
            sendBtn.disabled = false;
          }
        }
      );
    } else if (isSalesforce) {
      sfStatus.textContent = 'On Salesforce (navigate to a Lead or Contact)';
      sendBtn.disabled = true;
    } else {
      sfStatus.textContent = 'Not on a Salesforce page';
      sendBtn.disabled = true;
    }
  });
}

// ─── Last Sent Info ──────────────────────────────────────────────────────────

function loadLastSent() {
  chrome.storage.local.get('lastSent', (data) => {
    const container = document.getElementById('lastSent');
    const info = document.getElementById('lastSentInfo');

    if (data.lastSent) {
      const sent = data.lastSent;
      const date = new Date(sent.date);
      const formatted = date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
      });
      info.textContent = `${sent.name} (${sent.email}) — ${formatted}`;
      container.style.display = 'block';
    }
  });
}

// ─── Send VPA Email ──────────────────────────────────────────────────────────

function handleSend() {
  const sendBtn = document.getElementById('sendBtn');
  sendBtn.disabled = true;
  sendBtn.textContent = 'Creating draft...';

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) return;

    chrome.tabs.sendMessage(
      tabs[0].id,
      { type: 'TRIGGER_VPA_FROM_POPUP' },
      (response) => {
        sendBtn.disabled = false;
        sendBtn.textContent = 'Send VPA Email';

        if (chrome.runtime.lastError) {
          sendBtn.textContent = 'Error — refresh SF page';
          setTimeout(() => {
            sendBtn.textContent = 'Send VPA Email';
          }, 3000);
        } else if (response && response.success) {
          sendBtn.textContent = 'Draft created!';
          setTimeout(() => {
            sendBtn.textContent = 'Send VPA Email';
            loadLastSent();
          }, 2000);
        }
      }
    );
  });
}

// ─── Init ────────────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
  checkAuthStatus();
  checkSalesforcePage();
  loadLastSent();

  document.getElementById('sendBtn').addEventListener('click', handleSend);
  document
    .getElementById('settingsBtn')
    .addEventListener('click', () => {
      chrome.runtime.openOptionsPage();
    });
});
